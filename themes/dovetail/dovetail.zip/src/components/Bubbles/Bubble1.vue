<template>
  <v-img
    class="grow hidden-sm-and-down"
    contain
    max-height="200"
    width="100%"
    top="-10%"
    position="top right"
    :src="require('@/components/Illustration/bubbles1.png')"
  ></v-img>
</template>

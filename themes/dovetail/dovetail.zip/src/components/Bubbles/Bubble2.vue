<template>
  <v-img
    class="grow hidden-sm-and-down"
    contain
    max-height="200"
    width="100%"
    position="bottom left"
    style="position: absolute; right: 0; bottom: 0; width: 300px;"
    :src="require('@/components/Illustration/bubbles2.png')"
  ></v-img>
</template>

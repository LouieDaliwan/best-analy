<template>
  <svg id="Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" :width="width" :height="height" viewBox="0 0 817.61 595.07">
    <defs>
      <linearGradient id="linear-gradient" x1="380.87" y1="565.72" x2="382.9" y2="710.49" gradientTransform="translate(0 -172)" gradientUnits="userSpaceOnUse">
        <stop offset="0.01"/>
        <stop offset="0.97" stop-color="#3f3d56" stop-opacity="0"/>
      </linearGradient>
      <linearGradient id="linear-gradient-2" x1="412.59" y1="592.1" x2="384.25" y2="83.9" gradientTransform="translate(-3.2 -170.73)" gradientUnits="userSpaceOnUse">
        <stop offset="0.03" stop-color="#fff" stop-opacity="0"/>
        <stop offset="1" stop-color="#fff"/>
      </linearGradient>
      <linearGradient id="linear-gradient-3" x1="892.24" y1="-274.43" x2="317.43" y2="744.36" gradientTransform="translate(-3.2 -170.73)" xlink:href="#linear-gradient"/>
      <linearGradient id="linear-gradient-4" x1="801.75" y1="167.39" x2="514.56" y2="157.25" gradientTransform="matrix(1, 0, 0, -1, 0, 598)" xlink:href="#linear-gradient"/>
      <linearGradient id="linear-gradient-5" x1="587.95" y1="594.85" x2="613.05" y2="594.85" gradientTransform="translate(-3.2 -170.73)" gradientUnits="userSpaceOnUse">
        <stop offset="0" stop-color="#183866"/>
        <stop offset="1" stop-color="#1a7fc1"/>
      </linearGradient>
      <linearGradient id="linear-gradient-6" x1="386.47" y1="671.36" x2="385.03" y2="719.01" gradientTransform="translate(-3.2 -170.73)" xlink:href="#linear-gradient"/>
      <linearGradient id="linear-gradient-7" x1="260.64" y1="403.52" x2="-1.02" y2="409.53" xlink:href="#linear-gradient-2"/>
      <linearGradient id="linear-gradient-8" x1="323.53" y1="302.97" x2="285.06" y2="343.47" xlink:href="#linear-gradient-2"/>
      <linearGradient id="linear-gradient-9" x1="196" y1="376.56" x2="257.75" y2="533.47" xlink:href="#linear-gradient-2"/>
      <linearGradient id="linear-gradient-10" x1="455.64" y1="278.36" x2="549" y2="491.42" gradientTransform="translate(0 -172)" gradientUnits="userSpaceOnUse">
        <stop offset="0" stop-color="#fff" stop-opacity="0"/>
        <stop offset="1" stop-color="#fff"/>
      </linearGradient>
      <linearGradient id="linear-gradient-11" x1="402.14" y1="262.31" x2="405.17" y2="507.3" gradientTransform="translate(0 -172)" xlink:href="#linear-gradient-2"/>
      <linearGradient id="linear-gradient-12" x1="403.92" y1="428.49" x2="406.96" y2="673.48" gradientTransform="translate(0 -172)" gradientUnits="userSpaceOnUse">
        <stop offset="0.03" stop-color="#fff" stop-opacity="0"/>
        <stop offset="0.45" stop-color="#fff" stop-opacity="0.45"/>
        <stop offset="1" stop-color="#fff"/>
      </linearGradient>
      <linearGradient id="linear-gradient-13" x1="403.65" y1="428.49" x2="406.69" y2="673.48" gradientTransform="translate(0 -172)" xlink:href="#linear-gradient-2"/>
      <linearGradient id="linear-gradient-14" x1="510.02" y1="224.43" x2="510.31" y2="332.83" gradientTransform="matrix(1, 0, 0, -1, 0, 598)" xlink:href="#linear-gradient-12"/>
      <linearGradient id="linear-gradient-15" x1="510.13" y1="239.51" x2="510.41" y2="347.91" gradientTransform="matrix(1, 0, 0, -1, 0, 598)" xlink:href="#linear-gradient-12"/>
      <linearGradient id="linear-gradient-16" x1="510.19" y1="239.5" x2="510.47" y2="347.91" gradientTransform="matrix(1, 0, 0, -1, 0, 598)" xlink:href="#linear-gradient-12"/>
      <linearGradient id="linear-gradient-17" x1="630" y1="536.18" x2="666.85" y2="536.18" gradientTransform="translate(-3.2 -170.73)" gradientUnits="userSpaceOnUse">
        <stop offset="0" stop-color="#ecc4d7"/>
        <stop offset="0.16" stop-color="#edcbd5"/>
        <stop offset="0.42" stop-color="#efd4d1"/>
        <stop offset="0.7" stop-color="#f2eac9"/>
      </linearGradient>
      <linearGradient id="linear-gradient-18" x1="562.76" y1="630.47" x2="636.33" y2="617.78" gradientTransform="translate(-3.2 -170.73)" xlink:href="#linear-gradient"/>
      <linearGradient id="linear-gradient-19" x1="581.37" y1="590.6" x2="589.42" y2="590.6" xlink:href="#linear-gradient-17"/>
    </defs>
    <title>analyze_on_screen</title>
    <rect x="561.12" y="586.36" width="102.53" height="8.71" rx="3.85" fill="#1d2741" opacity="0.18" style="isolation: isolate"/>
    <path d="M381.45,5.34c-31.33,9.69-59,28.31-85.92,47.05Q188.18,127.17,86.62,209.85c-23.17,18.85-46.47,38.42-62.45,63.67-28.49,45-29.9,103.28-14.09,154.13S57.16,523.07,91,564.2c7.31,8.89,15.09,17.92,25.49,22.83s22.58,5.17,34.2,4.82c66.31-2,131.16-19.15,197-27,102.2-12.23,205.55-2,308.44,1,39.23,1.13,81,.53,114.07-20.64s52-62.47,46.44-101.34c-4.83-33.87-26.06-63.27-34-96.55-10.38-43.47,2.74-89.34-3.22-133.64-8.59-64.55-57.46-118-114.59-149.2C618,38.89,564.71,24.77,512.45,15.19,469.18,7.27,425.12-8.17,381.45,5.34Z" transform="translate(0 0)" :fill="iconColor" opacity="0.18" style="isolation: isolate"/>
    <rect x="294.42" y="402.55" width="175.05" height="136.14" :fill="iconColor"/>
    <rect x="294.42" y="402.55" width="175.05" height="136.14" fill="url(#linear-gradient)"/>
    <path d="M745.1,92.7V440.27a47.64,47.64,0,0,1-47.64,47.64H95.7a47.66,47.66,0,0,1-47.65-47.64V92.7A47.64,47.64,0,0,1,95.69,45.06H697.46a47.62,47.62,0,0,1,47.64,47.6v0Z" transform="translate(0 0)" :fill="iconColor"/>
    <path d="M745.1,92.7V440.27a47.64,47.64,0,0,1-47.64,47.64H95.7a47.52,47.52,0,0,1-29-9.81,47.35,47.35,0,0,1-9.81-29V101.57a47.64,47.64,0,0,1,47.64-47.64H706.34a47.35,47.35,0,0,1,29,9.81A47.42,47.42,0,0,1,745.1,92.7Z" transform="translate(0 0)" fill="url(#linear-gradient-2)"/>
    <path d="M745.1,402.55v37.72a47.64,47.64,0,0,1-47.64,47.64H95.7a47.64,47.64,0,0,1-47.65-47.63h0V402.55Z" transform="translate(0 0)" fill="url(#linear-gradient-3)"/>
    <path d="M653.15,428.27a144.09,144.09,0,0,1-4.72,38.5c-1.7,6.46-3.92,13-8.08,18.19a24.25,24.25,0,0,1-2.82,3H569.26c2.77-12,6.64-27.06,5.28-28.83-6.18-8.08-8.54-18.37-10.68-28.32-1.79-8.33-3.53-16.88-2.36-25.33.14-1,.31-2,.51-2.89,2.91-13.34,24.74-16.13,34.12-16.26l8,16.26c0,7.86,33.84-20.89,39.77-14.58,3.4,3.62,5.54,8.85,6.89,14.58C652.8,411.27,653.06,421.18,653.15,428.27Z" transform="translate(0 0)" fill="url(#linear-gradient-4)"/>
    <path d="M582.88,418.37,572.2,395.45a63.71,63.71,0,0,1,23.93-9.18,3.51,3.51,0,0,1,2.47.21,3.63,3.63,0,0,1,1.12,1.48c4.38,8.54,8.76,17.09,12.27,26,1.64,4.16,3.09,8.75,1.76,13-1.63,5.22-6.86,8.32-11.68,10.9C586.8,446.11,587.47,428.27,582.88,418.37Z" transform="translate(0 0)" fill="#fff"/>
    <path d="M605.08,412.12c-3.18,5.26-5.27,11.1-8.17,16.52-.49.91-1.23,1.95-2.26,1.84a2.6,2.6,0,0,1-1.18-.54,62.08,62.08,0,0,1-8.72-7.21c0,5.89,3.59,11.11,7,15.92a2.7,2.7,0,0,0,.89.89,2.3,2.3,0,0,0,1,.17A21.82,21.82,0,0,0,605,436.63a1.3,1.3,0,0,0,.54-.47,1.35,1.35,0,0,0,.12-.74c-.11-5.75-.67-11.75,1.59-17,.69-1.62,1.64-3.13,2.19-4.81.36-1.11,1.08-4.67-.7-5.06C607.32,408.2,605.66,411.16,605.08,412.12Z" transform="translate(0 0)" opacity="0.09" fill="url(#linear-gradient-5)" style="isolation: isolate"/>
    <path d="M531,542.2a12.09,12.09,0,0,1-.84,4.49,12.43,12.43,0,0,1-11.65,8h-273a12.48,12.48,0,0,1-11.65-8,12.09,12.09,0,0,1-.84-4.49,12.48,12.48,0,0,1,12.47-12.49h273A12.49,12.49,0,0,1,531,542.18Z" transform="translate(0 0)" :fill="iconColor"/>
    <path d="M531,542.2a12.09,12.09,0,0,1-.84,4.49,12.43,12.43,0,0,1-11.65,8h-273a12.48,12.48,0,0,1-11.65-8,12.09,12.09,0,0,1-.84-4.49,12.48,12.48,0,0,1,12.47-12.49h273A12.49,12.49,0,0,1,531,542.18Z" transform="translate(0 0)" fill="url(#linear-gradient-6)"/>
    <path d="M530.11,546.69a12.43,12.43,0,0,1-11.65,8h-273a12.48,12.48,0,0,1-11.65-8,12.28,12.28,0,0,1,2.82-4.35,12.46,12.46,0,0,1,8.83-3.66h273A12.48,12.48,0,0,1,530.11,546.69Z" transform="translate(0 0)" :fill="iconColor"/>
    <path d="M153.09,234a54.35,54.35,0,0,0,51.71,54.3v27.08a81.42,81.42,0,0,1,0-162.76V179.7A54.35,54.35,0,0,0,153.09,234Z" transform="translate(0 0)" fill="url(#linear-gradient-7)"/>
    <path d="M288.88,234a81.26,81.26,0,0,1-29.27,62.53l-17.47-20.68a54.37,54.37,0,0,0-34.69-96.22c-.88,0-1.75,0-2.62.07v-27h2.62A81.44,81.44,0,0,1,288.88,234Z" transform="translate(0 0)" fill="url(#linear-gradient-8)"/>
    <path d="M259.61,296.57a81.05,81.05,0,0,1-52.16,18.9c-.88,0-1.75,0-2.62-.05V288.34c.87,0,1.74.06,2.62.06a54.13,54.13,0,0,0,34.69-12.51Z" transform="translate(0 0)" fill="url(#linear-gradient-9)"/>
    <rect x="350.21" y="255.05" width="342.04" height="1.99" fill="url(#linear-gradient-10)"/>
    <path d="M346.47,183.5s65.07-9.73,81.52-38.89,50.11-35.9,77,19.44,70.31,60.58,86,41.88,35.9-86,63.57-87.5,37.65,52.35,37.65,52.35v68.06h-342Z" transform="translate(0 0)" :fill="iconColor"/>
    <rect x="352.7" y="281.98" width="103.71" height="7.48" fill="url(#linear-gradient-11)"/>
    <rect x="352.7" y="304.01" width="103.71" height="7.48" fill="url(#linear-gradient-12)"/>
    <rect x="352.7" y="326.04" width="103.71" height="7.48" fill="url(#linear-gradient-13)"/>
    <rect x="503.78" y="281.98" width="12.96" height="7.48" fill="url(#linear-gradient-14)"/>
    <rect x="503.78" y="304.01" width="12.96" height="7.48" fill="url(#linear-gradient-15)"/>
    <rect x="503.78" y="326.04" width="12.96" height="7.48" fill="url(#linear-gradient-16)"/>
    <path d="M626.86,363.42s12.67-23.93,21.47-22.17,17.6,10.91,14.78,17.95-17.41,20.07-17.86,26.4-11,3.52-11,3.52l-1.76-13.38S626.15,370.11,626.86,363.42Z" transform="translate(0 0)" fill="url(#linear-gradient-17)"/>
    <path d="M649.53,335.61c2.6-.84,5.42-.47,8.08.1s5.55,1.47,7.46,3.5c2.71,2.88,2.92,7.25,4.51,10.88,1.37,3.14,3.83,5.82,4.59,9.16a11.45,11.45,0,0,1-1.55,8.37,17.45,17.45,0,0,1-6.3,5.89c-2.24,1.3-4.69,2.24-6.86,3.66s-3.85,3.16-5.87,4.61a10.52,10.52,0,0,1-6.93,2.33,4.34,4.34,0,0,1-2.61-1.09c-1.35-1.3-1.28-3.45-1.13-5.32q.3-3.39.58-6.79a11.41,11.41,0,0,0,4.06-.53,3.94,3.94,0,0,0,2.6-2.94c.27-2-1.77-3.77-3.81-4s-4,.67-5.86,1.53c-.78-1.61.37-3.46,1.52-4.84a56.52,56.52,0,0,1,5.26-5.46,4.38,4.38,0,0,0,1.48-1.92c.52-1.84-1.33-3.37-2.12-4.82a18,18,0,0,1-1.33-3.84C644.18,340.27,645.48,336.91,649.53,335.61Z" transform="translate(0 0)" fill="#3f3d56"/>
    <path d="M660,461.52c-.5,3.31-1.13,6.69-2.81,9.59-5,8.59-16.73,9.87-26.67,9.66-4.81-.09-10.1-.55-14.16-2.84a12.53,12.53,0,0,1-4-3.42c-2.72-3.65-3-8.53-2.87-13.08.15-4.71.6-9.53.67-14.27.09-5.87-.42-11.62-2.82-16.91C606,427.35,611.8,416.92,613,414c2-4.73-4.1-1.78-2.15-6.51,2.15-5.21,4.43-10.6,8.65-14.3,6.54-5.7,16-6.05,24.7-6.1,1.4,0,3.34.64,3,2,6.67,1.83,10.23,12.6,11.57,19.37A154.7,154.7,0,0,1,660,461.52Z" transform="translate(0 0)" :fill="iconColor"/>
    <path d="M623.74,477.48a36.87,36.87,0,0,1-7.42.45,12.53,12.53,0,0,1-4-3.42c-2.72-3.65-3-8.53-2.87-13.08.15-4.71.6-9.53.67-14.27l13.59-27.29S628.54,476.45,623.74,477.48Z" transform="translate(0 0)" fill="url(#linear-gradient-18)"/>
    <path d="M640.23,480.33l10-2.85s2.77,2.89,0,14.24S646.59,582,646.59,582h-9l-8-73.34s-17.42,62.3-18.48,73.39H600.46s3.72-99.35,11.89-107.49C612.35,474.51,617.18,476.87,640.23,480.33Z" transform="translate(0 0)" fill="#3f3d56"/>
    <path d="M607.57,415.74s-3.81,28.18-8.68,27.74S585.62,426,585.62,426a9.58,9.58,0,0,0-6.2,9.47c0,7.55,7.52,14.63,7.52,14.63s21.69,15.49,27.86,3.15,10.3-42,10.3-42,9.14-23-.07-21.43C612.43,391.84,607.57,415.74,607.57,415.74Z" transform="translate(0 0)" :fill="iconColor"/>
    <path d="M579.49,423.7a19.09,19.09,0,0,1-.44-12.72,3,3,0,0,1,1.25,1.67l2.7,6.13a12.62,12.62,0,0,0,2.33-2.72,1.86,1.86,0,0,1,.87,1.95,11.79,11.79,0,0,1-.7,2.18,13.43,13.43,0,0,0-.08,5.95,20.61,20.61,0,0,1-2.13,1.7c-.64.44-1.48,1.28-2,.73s-.57-1.94-.83-2.56S579.8,424.48,579.49,423.7Z" transform="translate(0 0)" fill="url(#linear-gradient-19)"/>
    <path d="M611,582l-1.32,10.6H585.94s1.59-7.43,14.52-10.6Z" transform="translate(0 0)" fill="#3f3d56"/>
    <path d="M647,582l.84,10.6h-26s1.58-7.43,14.52-10.6Z" transform="translate(0 0)" fill="#3f3d56"/>
  </svg>
</template>

<script>
export default {
  props: {
    width: {
      type: [Number, String],
      default: 909
    },
    height: {
      type: [Number, String],
      default: 591
    },
   iconColor: {
      type: String,
      default: 'currentColor'
    }
  }
}
</script>

<style scoped>
svg {
  max-width: 100%;
}
</style>

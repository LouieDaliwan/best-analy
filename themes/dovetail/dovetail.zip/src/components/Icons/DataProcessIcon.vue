<template>
  <svg id="Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" :width="width" :height="height" viewBox="0 0 512.42 474.58">
    <defs>
      <linearGradient id="linear-gradient" x1="251.22" y1="89.52" x2="297.42" y2="89.52" gradientUnits="userSpaceOnUse">
        <stop offset="0" stop-color="#ecc4d7"/>
        <stop offset="0.42" stop-color="#efd4d1"/>
        <stop offset="1" stop-color="#f2eac9"/>
      </linearGradient>
      <linearGradient id="linear-gradient-2" x1="205.14" y1="62.74" x2="218.37" y2="62.74" gradientUnits="userSpaceOnUse">
        <stop offset="0.02" stop-color="#fff" stop-opacity="0"/>
        <stop offset="0.58" stop-color="#fff" stop-opacity="0.39"/>
        <stop offset="0.68" stop-color="#fff" stop-opacity="0.68"/>
        <stop offset="1" stop-color="#fff"/>
      </linearGradient>
      <linearGradient id="linear-gradient-3" x1="387.53" y1="225.32" x2="389.78" y2="278.28" gradientUnits="userSpaceOnUse">
        <stop offset="0" stop-opacity="0"/>
        <stop offset="0.99"/>
      </linearGradient>
      <linearGradient id="linear-gradient-4" x1="24.43" y1="271.2" x2="243.35" y2="271.2" xlink:href="#linear-gradient-3"/>
      <linearGradient id="linear-gradient-5" x1="310.41" y1="378.11" x2="307.03" y2="324.03" xlink:href="#linear-gradient-3"/>
      <linearGradient id="linear-gradient-6" x1="391.31" y1="372.8" x2="391.88" y2="337.03" xlink:href="#linear-gradient-3"/>
      <linearGradient id="linear-gradient-7" x1="124.3" y1="435.42" x2="123.52" y2="379.17" xlink:href="#linear-gradient-3"/>
      <linearGradient id="linear-gradient-8" x1="152.44" y1="412.19" x2="164.35" y2="-48.84" xlink:href="#linear-gradient-3"/>
      <linearGradient id="linear-gradient-9" x1="314.44" y1="227.93" x2="316.13" y2="274.69" xlink:href="#linear-gradient-3"/>
      <linearGradient id="linear-gradient-10" x1="341.82" y1="254.25" x2="348.96" y2="254.25" xlink:href="#linear-gradient-3"/>
      <linearGradient id="linear-gradient-11" x1="332.86" y1="254.25" x2="340" y2="254.25" xlink:href="#linear-gradient-3"/>
      <linearGradient id="linear-gradient-12" x1="324.01" y1="254.25" x2="331.16" y2="254.25" xlink:href="#linear-gradient-3"/>
      <linearGradient id="linear-gradient-13" x1="396.33" y1="196.28" x2="635.31" y2="201.53" xlink:href="#linear-gradient-3"/>
      <linearGradient id="linear-gradient-14" x1="375.45" y1="144.91" x2="817.78" y2="154.63" xlink:href="#linear-gradient-3"/>
      <linearGradient id="linear-gradient-15" x1="465.24" y1="247.02" x2="468.91" y2="321.61" xlink:href="#linear-gradient-3"/>
      <linearGradient id="linear-gradient-16" x1="593.04" y1="492.04" x2="-212.93" y2="426.17" gradientUnits="userSpaceOnUse">
        <stop offset="0" stop-opacity="0"/>
        <stop offset="0.41" stop-opacity="0.41"/>
        <stop offset="0.99"/>
      </linearGradient>
      <linearGradient id="linear-gradient-17" x1="207.52" y1="85.8" x2="253.71" y2="85.8" xlink:href="#linear-gradient-2"/>
      <linearGradient id="linear-gradient-18" x1="299.42" y1="156.03" x2="230.97" y2="166.45" xlink:href="#linear-gradient-3"/>
      <linearGradient id="linear-gradient-19" x1="225.1" y1="35.18" x2="255.32" y2="35.18" xlink:href="#linear-gradient"/>
      <linearGradient id="linear-gradient-20" x1="208.09" y1="79.76" x2="238.88" y2="65.3" xlink:href="#linear-gradient-2"/>
      <linearGradient id="linear-gradient-21" x1="225.73" y1="88.51" x2="286.5" y2="88.51" xlink:href="#linear-gradient"/>
      <linearGradient id="linear-gradient-22" x1="232.6" y1="208.37" x2="255.42" y2="208.37" xlink:href="#linear-gradient-3"/>
      <linearGradient id="linear-gradient-23" x1="259.36" y1="192.31" x2="282.17" y2="192.31" xlink:href="#linear-gradient-3"/>
    </defs>
    <title>Data Process</title>
    <g>
      <path d="M113.42,58.92C131,29.49,169.2,19.71,203.48,19.72s69,7.06,102.53,0c15.47-3.28,30.4-9.52,46.18-10.35,33.52-1.77,62.9,20.66,88.88,41.89l47.52,38.85c19.25,15.74,39,32.08,50.67,54.05a94.73,94.73,0,0,1,9,63c-5.48,26.52-22.45,51.63-18.21,78.38,2.13,13.44,9.47,25.4,14.24,38.15a103.18,103.18,0,0,1-62,133.35c-35.84,12.76-75.23,4.92-112.92-.24-71.81-9.84-144.57-9.38-216.92-13.61-12.55-.73-25.9-1.91-35.83-9.62-14.29-11.1-16.51-31.53-16.92-49.63-1.09-47.7,2.36-95.4,7.12-142.88,3.5-34.86,1.43-61.56-9.51-94.31C89.66,123.82,100.62,80.34,113.42,58.92Z" transform="translate(-44.82 -5.37)" :fill="iconColor" opacity="0.18" style="isolation: isolate"/>
      <path d="M260.8,78,265,85.3l29.43-13.1,3,4.65s-30.56,30.42-32.39,30-13.81-21.68-13.81-21.68Z" transform="translate(-44.82 -5.37)" fill="url(#linear-gradient)"/>
      <polygon points="205.14 44.72 218.37 70.63 206.83 80.77 205.14 44.72" :fill="iconColor"/>
      <polygon points="205.14 44.72 218.37 70.63 206.83 80.77 205.14 44.72" opacity="0.69" fill="url(#linear-gradient-2)" style="isolation: isolate"/>
      <polygon points="230.86 93.54 238 44.72 266.54 44.34 257.15 93.92 230.86 93.54" :fill="iconColor"/>
      <path d="M356.07,266.71h8.39V206.29a15,15,0,0,1,15-15h39.15v-8.39H379.42a23.37,23.37,0,0,0-23.35,23.35Z" transform="translate(-44.82 -5.37)" :fill="iconColor"/>
      <path d="M356.26,266.71h8.39V206.29a15,15,0,0,1,15-15h39.16v-8.39H379.6a23.37,23.37,0,0,0-23.34,23.35Z" transform="translate(-44.82 -5.37)" fill="url(#linear-gradient-3)"/>
      <rect x="24.43" y="133.32" width="218.92" height="275.75" rx="34.55" fill="url(#linear-gradient-4)"/>
      <path d="M276.76,384.5h0a4.2,4.2,0,0,1,4.19-4.19h36.93a15,15,0,0,0,14.95-15V326.2h8.4v39.15a23.35,23.35,0,0,1-23.35,23.35H281A4.2,4.2,0,0,1,276.76,384.5Z" transform="translate(-44.82 -5.37)" :fill="iconColor"/>
      <path d="M433.3,397.73v-8.39H372.88a15,15,0,0,1-15-15V335.23h-8.39v39.15a23.37,23.37,0,0,0,23.35,23.35Z" transform="translate(-44.82 -5.37)" :fill="iconColor"/>
      <path d="M276.76,384.5h0a4.2,4.2,0,0,1,4.19-4.19h36.93a15,15,0,0,0,14.95-15V326.2h8.4v39.15a23.35,23.35,0,0,1-23.35,23.35H281A4.2,4.2,0,0,1,276.76,384.5Z" transform="translate(-44.82 -5.37)" fill="url(#linear-gradient-5)"/>
      <path d="M433.3,397.73v-8.39H372.88a15,15,0,0,1-15-15V335.23h-8.39v39.15a23.37,23.37,0,0,0,23.35,23.35Z" transform="translate(-44.82 -5.37)" fill="url(#linear-gradient-6)"/>
      <path d="M557.24,465.78A14.19,14.19,0,0,1,543.05,480H73.48a14.19,14.19,0,0,1-2.81-28.09,14.47,14.47,0,0,1,2.81-.28H543.05A14.19,14.19,0,0,1,557.24,465.78Z" transform="translate(-44.82 -5.37)" :fill="iconColor"/>
      <rect x="33.39" y="391.07" width="181.21" height="61.45" :fill="iconColor"/>
      <rect x="33.39" y="391.07" width="181.21" height="45.05" fill="url(#linear-gradient-7)"/>
      <rect y="133.32" width="218.92" height="275.76" rx="34.55" :fill="iconColor"/>
      <path d="M263.74,301.93v78a34.56,34.56,0,0,1-34.55,34.55H79.37A34.56,34.56,0,0,1,44.82,379.9v-78a34.55,34.55,0,0,1,34.55-34.55H229.19A34.55,34.55,0,0,1,263.74,301.93Z" transform="translate(-44.82 -5.37)" fill="url(#linear-gradient-8)"/>
      <rect x="261.61" y="250.15" width="90.38" height="85.25" fill="#435276"/>
      <g>
        <rect x="254.42" y="238.05" width="106.3" height="33.68" rx="9.08" :fill="iconColor"/>
        <rect x="254.42" y="276.99" width="106.3" height="33.68" rx="9.08" :fill="iconColor"/>
        <rect x="254.42" y="315.93" width="106.3" height="33.68" rx="9.08" :fill="iconColor"/>
      </g>
      <path d="M348.71,243.6h-8.39V183.18a15,15,0,0,0-15-15H280.43a4.2,4.2,0,0,1-4.2-4.2h0a4.2,4.2,0,0,1,4.2-4.19h44.93a23.34,23.34,0,0,1,23.35,23.35Z" transform="translate(-44.82 -5.37)" :fill="iconColor"/>
      <path d="M348.71,243.6h-8.39V183.18a15,15,0,0,0-15-15H280.43a4.2,4.2,0,0,1-4.2-4.2h0a4.2,4.2,0,0,1,4.2-4.19h44.93a23.34,23.34,0,0,1,23.35,23.35Z" transform="translate(-44.82 -5.37)" fill="url(#linear-gradient-9)"/>
      <circle cx="345.39" cy="254.25" r="3.57" fill="url(#linear-gradient-10)"/>
      <circle cx="336.43" cy="254.25" r="3.57" fill="url(#linear-gradient-11)"/>
      <circle cx="327.58" cy="254.25" r="3.57" fill="url(#linear-gradient-12)"/>
      <path d="M354.69,97.05H522.83a16.54,16.54,0,0,0,16.55-16.54h0a34.67,34.67,0,0,0-34.67-34.67H490.53a34.66,34.66,0,0,0-34.66-34.66H433a34.66,34.66,0,0,0-34.67,34.66v7.09H379a34.67,34.67,0,0,0-34.64,33.43h0A10.32,10.32,0,0,0,354.69,97.05Z" transform="translate(-44.82 -5.37)" :fill="iconColor"/>
      <path d="M162.51,97.05h-102a8.13,8.13,0,0,1-8.14-8.13V87.19A20.67,20.67,0,0,1,73,66.52H81.5a20.68,20.68,0,0,1,20.67-20.68H115.8a20.67,20.67,0,0,1,20.67,20.68v4.22H148a20.68,20.68,0,0,1,20.66,19.94h0A6.15,6.15,0,0,1,162.51,97.05Z" transform="translate(-44.82 -5.37)" :fill="iconColor"/>
      <rect x="27.62" y="199.36" width="164.4" height="20.48" rx="10.24" fill="#fff"/>
      <rect x="32.11" y="203.32" width="107.3" height="13.37" rx="6.68" :fill="iconColor"/>
      <g>
        <rect x="369.78" y="133.32" width="101.66" height="128.06" rx="16.04" :fill="iconColor"/>
        <rect x="418.62" y="133.32" width="52.81" height="128.06" rx="16.04" fill="url(#linear-gradient-13)"/>
        <path d="M516.26,154.74H414.6a16,16,0,0,1,16-16.05h69.57A16,16,0,0,1,516.26,154.74Z" transform="translate(-44.82 -5.37)" fill="url(#linear-gradient-14)"/>
        <path d="M516.26,250.71a16,16,0,0,1-16.05,16H430.64a16,16,0,0,1-16-16Z" transform="translate(-44.82 -5.37)" fill="url(#linear-gradient-15)"/>
      </g>
      <path d="M545.75,444.34H430V297.51l85.91-1,31.16,23.22ZM434.42,440h107l1.28-118L514.5,301l-80.08.9Z" transform="translate(-44.82 -5.37)" :fill="iconColor"/>
      <path d="M545.94,323.3l-26.26.43-4.59-25.64Zm-22.58-4,12.87-.71-14.69-10.3Z" transform="translate(-44.82 -5.37)" :fill="iconColor"/>
      <rect x="406.32" y="324.1" width="77.47" height="5.09" rx="2.54" :fill="iconColor"/>
      <rect x="406.32" y="340.91" width="77.47" height="5.09" rx="2.54" :fill="iconColor"/>
      <rect x="406.32" y="357.72" width="77.47" height="5.09" rx="2.54" :fill="iconColor"/>
      <rect x="406.32" y="374.52" width="77.47" height="5.09" rx="2.54" :fill="iconColor"/>
      <rect x="406.32" y="391.33" width="77.47" height="5.09" rx="2.54" :fill="iconColor"/>
      <rect x="406.32" y="408.14" width="77.47" height="5.09" rx="2.54" :fill="iconColor"/>
      <path d="M299.65,219.73H277.57a1.87,1.87,0,0,1-1.86-1.87h0a1.86,1.86,0,0,1,1.86-1.86h22.08a17.27,17.27,0,0,0,17.26-17.27V161.62a20.21,20.21,0,0,1,20.21-20.21h44.23a18.56,18.56,0,0,0,18.55-18.55v-30h3.73v30a22.29,22.29,0,0,1-22.28,22.28H337.12a16.48,16.48,0,0,0-16.48,16.48v37.11A21,21,0,0,1,299.65,219.73Z" transform="translate(-44.82 -5.37)" :fill="iconColor"/>
      <path d="M168.86,137.24h3.73v-2.18a20.2,20.2,0,0,0-20.17-20.17H133a15.58,15.58,0,0,1-15.55-15.56V96.27h-3.73v3.06A19.31,19.31,0,0,0,133,118.62h19.43a16.45,16.45,0,0,1,16.44,16.44Z" transform="translate(-44.82 -5.37)" :fill="iconColor"/>
      <rect x="383.99" y="161.02" width="74.85" height="50.42" fill="#fff" opacity="0.25"/>
      <path d="M487.38,466.06A14.19,14.19,0,0,1,476.06,480H73.48a14.19,14.19,0,0,1-2.81-28.09H473.2A14.18,14.18,0,0,1,487.38,466.06Z" transform="translate(-44.82 -5.37)" fill="url(#linear-gradient-16)"/>
      <path d="M207.52,69v56h46.19V65.2s.47-19.34-9.67-18.49S211.83,43,207.52,69Z" transform="translate(-44.82 -5.37)" :fill="iconColor"/>
      <path d="M207.52,69v56h46.19V65.2s.47-19.34-9.67-18.49S211.83,43,207.52,69Z" transform="translate(-44.82 -5.37)" opacity="0.69" fill="url(#linear-gradient-17)" style="isolation: isolate"/>
      <path d="M253.71,124.92s30,.94,38.5,15,20.28,49.58,20.28,49.58l-10.71,4.22-19.15-24.22Z" transform="translate(-44.82 -5.37)" fill="#fff"/>
      <path d="M253.71,124.92s30,.94,38.5,15,20.28,49.58,20.28,49.58l-10.71,4.22-19.15-24.22Z" transform="translate(-44.82 -5.37)" fill="url(#linear-gradient-18)"/>
      <path d="M207.52,124.92s-4.14,20.66,6.76,24,44.31,6.76,44.31,6.76l16.53,54.83,13.71-6.2s-5.07-59.53-11.83-67-23.29-12.39-23.29-12.39Z" transform="translate(-44.82 -5.37)" fill="#fff"/>
      <path d="M231,29.8a34.18,34.18,0,0,1,2.5-8.3,14.81,14.81,0,0,1,12.34-7.84,6.74,6.74,0,0,1,1.85.13,6.18,6.18,0,0,1,1.84.81,12.79,12.79,0,0,1,5.3,8.35,37.24,37.24,0,0,1,.25,10.12c-.25,3.68-.92,8-4.2,9.67-2.28,1.15-5,.56-7.47-.2a1.87,1.87,0,0,0-1.57,0,1.73,1.73,0,0,0-.58,1.21c-.56,3.58.59,7.3-.23,10.82a2.79,2.79,0,0,1-1.27,2,3,3,0,0,1-2,0,20.48,20.48,0,0,1-8.66-4.69c-1-.93-3.63-2.54-4-3.86s1.52-4.17,2-5.47A92.64,92.64,0,0,0,231,29.8Z" transform="translate(-44.82 -5.37)" fill="url(#linear-gradient-19)"/>
    </g>
    <path d="M208,69.05l14.27,27,15.21-11.26S226.2,56.66,224,55.53s-7.61-4.5-10.14-.84S207.52,64.26,208,69.05Z" transform="translate(-44.82 -5.37)" opacity="0.69" fill="url(#linear-gradient-20)" style="isolation: isolate"/>
    <path d="M225.73,94.31s6.2,11,9,11.27,42.82-17.19,42.82-17.19l6.2-2s1.41-6.76,1.69-8.17,2.53-6.19-.57-6.76S277,74.87,277,74.87l-2.26,5.64-33.8,10.42-3.47-6.1Z" transform="translate(-44.82 -5.37)" fill="url(#linear-gradient-21)"/>
    <path d="M261.77,14.79c1.41-3.22.13-7.71-3.22-8.79-2.76-.9-5.69.67-8.59.73-2.47,0-4.83-1-7.28-1.29a12.34,12.34,0,0,0-13,9.19,9.82,9.82,0,0,1-.73,2.53c-1,1.81-3.56,2.56-4.06,4.57a5.26,5.26,0,0,0,.4,2.91l3.18,9.47c.36,1.06,1.17,2.36,2.23,2,.59-.2.87-.86,1.09-1.46l2.13-5.93c1.92-.17,1.5,4.3,3.41,4,1.24-.2,1-2,.69-3.26a6.35,6.35,0,0,1,5.23-7.33,7.75,7.75,0,0,0,2.73-.45,17,17,0,0,1,1.69-1.12c2.35-.88,4.84,1.09,7.52.07A11.82,11.82,0,0,0,261.77,14.79Z" transform="translate(-44.82 -5.37)" fill="#3f3d56"/>
    <polygon points="239.5 200.76 241.47 206.12 256.68 205.84 237.53 214.57 233.87 202.74 239.5 200.76" :fill="iconColor"/>
    <polygon points="238.23 201.47 240.21 206.82 255.41 206.54 236.26 215.27 232.6 203.44 238.23 201.47" fill="url(#linear-gradient-22)"/>
    <polygon points="266.26 184.71 268.23 190.06 283.44 189.78 264.29 198.51 260.63 186.68 266.26 184.71" :fill="iconColor"/>
    <polygon points="264.99 185.41 266.96 190.77 282.18 190.48 263.02 199.22 259.36 187.38 264.99 185.41" fill="url(#linear-gradient-23)"/>
  </svg>
</template>

<script>
export default {
  props: {
    width: {
      type: [Number, String],
      default: 512
    },
    height: {
      type: [Number, String],
      default: 474
    },
    iconColor: {
      type: String,
      default: 'currentColor'
    }
  }
}
</script>

<style scoped>
svg {
  max-width: 100%;
}
</style>

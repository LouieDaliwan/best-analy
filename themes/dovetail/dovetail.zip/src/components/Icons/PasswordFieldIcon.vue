<template>
  <svg :width="width" :height="height" id="Layer_1" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 421.26 322.03"><defs><linearGradient id="linear-gradient" x1="170.51" y1="103.77" x2="205.81" y2="388.4" gradientUnits="userSpaceOnUse"><stop offset="0" stop-opacity="0"/><stop offset="0.99"/></linearGradient><linearGradient id="linear-gradient-2" x1="226.33" y1="280.91" x2="224.92" y2="228.82" xlink:href="#linear-gradient"/><linearGradient id="linear-gradient-3" x1="202.61" y1="72.94" x2="110.36" y2="131.04" xlink:href="#linear-gradient"/><linearGradient id="linear-gradient-4" x1="197.85" y1="79.71" x2="127.35" y2="124.11" xlink:href="#linear-gradient"/><linearGradient id="linear-gradient-5" x1="159.09" y1="137.11" x2="158.78" y2="123.36" xlink:href="#linear-gradient"/><linearGradient id="linear-gradient-6" x1="227.03" y1="237.99" x2="226.55" y2="294.8" xlink:href="#linear-gradient"/></defs><path d="M396,113.25c-17.19-19.53-39.22-34.06-61-48.35-26.33-17.3-53.81-35.05-85-39.34-29.79-4.1-60.21,4.68-86.61,19.09S114,78.86,91.21,98.5L37.58,144.76c-11.28,9.73-22.88,19.86-29.3,33.3-5.45,11.4-6.74,24.44-5.7,37a107.94,107.94,0,0,0,39.05,74C57.21,301.69,76,309.66,94.69,317c34.34,13.44,69.74,25.3,106.47,28.6,39.22,3.53,78.58-2.82,117.44-9.15,47.72-7.77,75.1-28.06,83-75.07,4.29-25.44,18.2-48.49,21.12-74C425.89,159.91,413.77,133.48,396,113.25Z" transform="translate(-1.99 -24.55)" :fill="iconColor" opacity="0.18" style="isolation:isolate"/><rect x="71.09" y="32.9" width="316.78" height="223.86" rx="13.42" :fill="iconColor"/><rect x="81.88" y="40.51" width="295.27" height="205.46" rx="12.41" fill="#fff"/><polygon points="267.49 221.56 221.03 198.33 72.03 198.33 72.03 144.69 285.8 144.69 266.79 183.08 267.49 221.56" fill="url(#linear-gradient)"/><path d="M287.79,91.67V196.38A13.83,13.83,0,0,1,274,210.21H60.85a13.8,13.8,0,0,1-13.8-13.83V91.67a13.8,13.8,0,0,1,13.8-13.8H274A13.82,13.82,0,0,1,287.79,91.67Z" transform="translate(-1.99 -24.55)" :fill="iconColor"/><path d="M167.21,104.72a2.55,2.55,0,0,1-3.23-1.45l-2.42-6.43a7.18,7.18,0,0,0-13.43,5.08l3.35,8.85a2.5,2.5,0,0,1,.12.45h-5.3l-2.85-7.53a12.18,12.18,0,0,1,22.78-8.62l2.43,6.42A2.5,2.5,0,0,1,167.21,104.72Z" transform="translate(-1.99 -24.55)" fill="#fff"/><rect x="45.75" y="254.65" width="360.42" height="25.34" rx="12.02" :fill="iconColor"/><rect x="45.75" y="254.65" width="360.42" height="25.34" rx="12.02" fill="url(#linear-gradient-2)"/><polygon points="225.25 184.96 267.49 221.56 267.49 176.86 225.25 184.96" :fill="iconColor"/><rect x="76.25" y="127.7" width="175.52" height="30.04" rx="6.19" fill="#fff"/><rect x="140.19" y="86.73" width="32.85" height="30.35" fill="url(#linear-gradient-3)"/><rect x="152.4" y="86.67" width="20.6" height="30.35" fill="url(#linear-gradient-4)"/><path d="M157.82,125.44s-3.24-2.7-.41-5,6,2.5,3,5l2.11,5.63H155.4Z" transform="translate(-1.99 -24.55)" fill="url(#linear-gradient-5)"/><circle cx="101.38" cy="142.02" r="6.27"/><circle cx="118.29" cy="142.02" r="6.27"/><circle cx="135.2" cy="142.02" r="6.27"/><circle cx="152.11" cy="142.02" r="6.27"/><circle cx="170.35" cy="142.02" r="6.27"/><circle cx="187.26" cy="142.02" r="6.27"/><circle cx="204.17" cy="142.02" r="6.27"/><circle cx="221.09" cy="142.02" r="6.27"/><path d="M55.48,68.08a5,5,0,0,1-4.58-3L40.1,40.2a5,5,0,1,1,9.18-4L60.07,61.09a5,5,0,0,1-4.59,7Z" transform="translate(-1.99 -24.55)" :fill="iconColor"/><path d="M7,102.19a5,5,0,0,1-.33-10l27.05-1.81a5,5,0,1,1,.67,10L7.33,102.18Z" transform="translate(-1.99 -24.55)" :fill="iconColor"/><path d="M35.77,77.58A4.94,4.94,0,0,1,33,76.72L10.53,61.48a5,5,0,0,1,5.62-8.27L38.58,68.45a5,5,0,0,1-2.81,9.13Z" transform="translate(-1.99 -24.55)" :fill="iconColor"/><rect x="190.29" y="254.88" width="73.12" height="7.51" fill="url(#linear-gradient-6)"/></svg>
</template>

<script>
export default {
  props: {
    width: {
      type: [Number, String],
      default: 400
    },
    height: {
      type: [Number, String],
      default: 400
    },
    iconColor: {
      type: String,
      default: 'currentColor'
    }
  }
}
</script>

<style scoped>
svg {
  max-width: 100%;
}
</style>

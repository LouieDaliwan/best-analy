import admin from './admin'

export default []
  .concat(
    admin,
  )

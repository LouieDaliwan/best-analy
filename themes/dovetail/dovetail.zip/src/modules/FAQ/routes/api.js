export default {
  url: function () {
    return '/api/v1/faqs/contents'
  },
}

<template>
  <v-card class="mb-3">
    <v-card-title class="pb-0">{{ __('Icon') }}</v-card-title>
    <v-card-text class="text-center">
      <div class="d-flex justify-center">
        <v-skeleton-loader class="dt-skeleton-avatar-upload" type="avatar"></v-skeleton-loader>
      </div>
    </v-card-text>
  </v-card>
</template>

<template>
  <v-row>
    <v-col cols="12">
      <v-card class="mb-3">
        <v-card-text>
          <v-row>
            <v-col cols="12">
              <v-skeleton-loader class="mb-6" height="56" type="image"></v-skeleton-loader>
            </v-col>
            <v-col cols="12">
              <v-skeleton-loader class="mb-6" height="56" type="image"></v-skeleton-loader>
            </v-col>
            <v-col cols="12">
              <v-skeleton-loader class="mb-6" height="56" type="image"></v-skeleton-loader>
            </v-col>
            <v-col cols="12">
              <v-skeleton-loader class="mb-6" height="56" type="image"></v-skeleton-loader>
            </v-col>
            <v-col cols="12">
              <v-skeleton-loader class="mb-6" height="56" type="image"></v-skeleton-loader>
            </v-col>
            <v-col cols="12">
              <v-skeleton-loader class="mb-6" height="56" type="image"></v-skeleton-loader>
            </v-col>
            <v-col cols="12">
              <v-skeleton-loader class="mb-6" height="56" type="image"></v-skeleton-loader>
            </v-col>
          </v-row>
        </v-card-text>
      </v-card>
    </v-col>
  </v-row>
</template>

export default {
  list: function () {
    return '/api/v1/settings/app'
  },

  update: function () {
    return '/api/v1/settings/branding'
  },
}

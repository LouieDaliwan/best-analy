export default [
  // {
  //   code: 'tests.index',
  //   name: 'tests.index',
  //   meta: {
  //     title: 'UI Tests',
  //     icon: 'mdi-flask',
  //     authenticatable: true,
  //     sort: 500,
  //     permission: 'users.index',
  //   }
  // }
]

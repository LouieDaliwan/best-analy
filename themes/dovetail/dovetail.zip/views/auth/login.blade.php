@extends('dovetail::app')

@push('css')
  <!-- Login page -->
@endpush

@section('page:content')
asd
  <login-form></login-form>
@endsection

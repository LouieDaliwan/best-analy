<v-card>
  <v-card-text>{{ $quote }}</v-card-text>
</v-card>
